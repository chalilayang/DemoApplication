package com.example.mi.view;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.mi.demoapplication.R;

public class WirelessRapidChargeView extends FrameLayout
        implements ValueAnimator.AnimatorUpdateListener,
        Animator.AnimatorListener, SurfaceFrameAnimation.FrameAnimationListener {

    private static final String TAG = "ChargingQuickView";

    private static final int DISMISS_DURATION = 400;
    private static final int SWITCH_DURATION = 300;
    private static final String RES_ID_NORMAL_PRE = "wireless_normal_charge_";
    private static final String RES_ID_RAPID_PRE = "wireless_rapid_charge_";
    public static final int ENTER_ANIMATION = 400;
    public static final int ANIMATION_DURATION = 10000;
    private static final int FRAME_INTERVAL = 32;
    private static final int FRAME_COUNT_NORMAL = 36;
    private static final int FRAME_COUNT_RAPID = 24;

    private static final float CHARGE_NUMBER_SCALE_SMALL = 0.7f;
    private static final int CHARGE_NUMBER_TRANSLATE_SMALL = -10;
    private static final int CHARGE_TIP_TRANSLATE_SMALL = -20;

    private RelativeLayout contentContainer;
    private PercentCountView percentCountView;
    private TextView stateTipNormal;
    private TextView stateTipRapid;
    private ImageView carModeIcon;
    private ImageView rapidIcon;

    private FrameAnimationView circleView;
    private FrameAnimationView circleRapidView;
    private ValueAnimator zoomAnimator;

    private WindowManager windowManager;
    private Handler handler = new Handler();

    private boolean isRapidCharge = false;
    private boolean isScreenOn;
    private boolean carMode;
    private boolean mStartingDismissWirelessAlphaAnim;

    private AnimatorSet circleSwitchAnimator;
    private AnimatorSet contentSwitchAnimator;
    public WirelessRapidChargeView(Context context) {
        this(context, null);
    }

    public WirelessRapidChargeView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public WirelessRapidChargeView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }

    private void init(Context context) {
        isRapidCharge = false;
        carMode = false;
        setBackgroundColor(Color.argb(0.9f, 0f,0f,0f));
        hideSystemUI();
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);

        LayoutParams flp = new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        flp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM;

        contentContainer = new RelativeLayout(context);
        View centerAnchorView = new TextView(context);
        RelativeLayout.LayoutParams rlp = new RelativeLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, (int) (4f * getResources().getDisplayMetrics().density));
        rlp.addRule(RelativeLayout.CENTER_IN_PARENT);
        centerAnchorView.setId(View.generateViewId());
        contentContainer.addView(centerAnchorView, rlp);

        rlp = new RelativeLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        rlp.addRule(RelativeLayout.CENTER_HORIZONTAL);
        rlp.addRule(RelativeLayout.ABOVE, centerAnchorView.getId());
        percentCountView = new PercentCountView(context);
        contentContainer.addView(percentCountView, rlp);

        stateTipNormal = new TextView(context);
        stateTipNormal.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15.54f);
        stateTipNormal.setIncludeFontPadding(false);
        stateTipNormal.setTextColor(Color.parseColor("#8CFFFFFF"));
        stateTipNormal.setGravity(Gravity.CENTER);
        stateTipNormal.setText(getResources().getString(R.string.wireless_normal_charge_mode_tip));
        rlp = new RelativeLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        rlp.addRule(RelativeLayout.CENTER_HORIZONTAL);
        rlp.addRule(RelativeLayout.BELOW, centerAnchorView.getId());
        contentContainer.addView(stateTipNormal, rlp);

        stateTipRapid = new TextView(context);
        stateTipRapid.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15.54f);
        stateTipRapid.setIncludeFontPadding(false);
        stateTipRapid.setTextColor(Color.parseColor("#8CFFFFFF"));
        stateTipRapid.setGravity(Gravity.CENTER);
        stateTipRapid.setText(getResources().getString(R.string.wireless_rapid_charge_mode_tip));
        rlp = new RelativeLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        rlp.addRule(RelativeLayout.CENTER_HORIZONTAL);
        rlp.addRule(RelativeLayout.BELOW, centerAnchorView.getId());
        contentContainer.addView(stateTipRapid, rlp);

        rapidIcon = new ImageView(context);
        rapidIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int redId = getResources().getIdentifier(
                "charge_mode_car", "drawable", context.getPackageName());
        rapidIcon.setImageResource(redId);
        rapidIcon.setScaleX(0);
        rapidIcon.setScaleY(0);
        flp = new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        flp.gravity = Gravity.CENTER;
        int paddingTop = (int) (stateTipNormal.getTextSize() * 6);
        rapidIcon.setPadding(0, paddingTop, 0, 0);
        addView(rapidIcon, flp);

        carModeIcon = new ImageView(context);
        carModeIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        redId = getResources().getIdentifier(
                "charge_mode_car", "drawable", context.getPackageName());
        carModeIcon.setImageResource(redId);
        carModeIcon.setScaleX(0);
        carModeIcon.setScaleY(0);
        flp = new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        flp.gravity = Gravity.CENTER;
        paddingTop = (int) (stateTipNormal.getTextSize() * 6);
        carModeIcon.setPadding(0, paddingTop, 0, 0);
        addView(carModeIcon, flp);

        flp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        addView(contentContainer, flp);

        flp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        flp.gravity = Gravity.CENTER;
        circleView = new FrameAnimationView(context, FRAME_COUNT_NORMAL, FRAME_INTERVAL, RES_ID_NORMAL_PRE, ANIMATION_DURATION);
        circleView.setAnimationCallback(this);
        addView(circleView, flp);
        circleView.setAlpha(1f);

        flp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        flp.gravity = Gravity.CENTER;
        circleRapidView = new FrameAnimationView(context, FRAME_COUNT_RAPID, FRAME_INTERVAL, RES_ID_RAPID_PRE, ANIMATION_DURATION);
        circleRapidView.setAnimationCallback(this);
        addView(circleRapidView, flp);
        circleRapidView.setAlpha(0.0f);
    }

    public void setIsRapidCharge(boolean rapid) {
        if (rapid != isRapidCharge) {
            startSwitchAnimation();
            startContentSwitchAnimation();
            isRapidCharge = rapid;
        }
    }

    public void setCarMode(boolean isCarMode) {
        if (isCarMode != carMode) {
            startContentSwitchAnimation();
            carMode = isCarMode;
        }
    }

    private void startSwitchAnimation() {
        if (circleSwitchAnimator != null) {
            circleSwitchAnimator.cancel();
        }
        Log.i(TAG, "startSwitchAnimation: " + isRapidCharge + " " + circleRapidView.getAlpha() + " " + circleView.getAlpha());
        PropertyValuesHolder alphaProperty = PropertyValuesHolder.ofFloat(
                ALPHA,circleRapidView.getAlpha(), isRapidCharge ? 1 : 0);
        final ObjectAnimator circleRapidAnimator = ObjectAnimator.ofPropertyValuesHolder(
                circleRapidView, alphaProperty).setDuration(SWITCH_DURATION);
        alphaProperty = PropertyValuesHolder.ofFloat(
                ALPHA,circleView.getAlpha(), isRapidCharge ? 0 : 1);
        final ObjectAnimator circleAnimator = ObjectAnimator.ofPropertyValuesHolder(
                circleView, alphaProperty).setDuration(SWITCH_DURATION);
        circleSwitchAnimator = new AnimatorSet();
        circleSwitchAnimator.playTogether(circleRapidAnimator, circleAnimator);
        circleSwitchAnimator.start();
    }

    private void startContentSwitchAnimation() {
        if (contentSwitchAnimator != null) {
            contentSwitchAnimator.cancel();
        }
        PropertyValuesHolder scaleXProperty = PropertyValuesHolder.ofFloat(
                SCALE_X, percentCountView.getScaleX(), isRapidCharge ? CHARGE_NUMBER_SCALE_SMALL : 1);
        PropertyValuesHolder scaleYProperty = PropertyValuesHolder.ofFloat(
                SCALE_Y, percentCountView.getScaleY(), isRapidCharge ? CHARGE_NUMBER_SCALE_SMALL : 1);
        PropertyValuesHolder translationYProperty = PropertyValuesHolder.ofFloat(
                TRANSLATION_Y, percentCountView.getTranslationY(), isRapidCharge ? CHARGE_NUMBER_TRANSLATE_SMALL : 0);
        final ObjectAnimator numberAnimator = ObjectAnimator.ofPropertyValuesHolder(
                percentCountView, scaleXProperty, scaleYProperty, translationYProperty).setDuration(SWITCH_DURATION);

        translationYProperty = PropertyValuesHolder.ofFloat(
                TRANSLATION_Y, stateTipNormal.getTranslationY(), isRapidCharge ? CHARGE_TIP_TRANSLATE_SMALL : 0);
        PropertyValuesHolder alphaProperty = PropertyValuesHolder.ofFloat(
                ALPHA, stateTipNormal.getAlpha(), isRapidCharge ? 0 : 1);
        final ObjectAnimator tipAnimator = ObjectAnimator.ofPropertyValuesHolder(
                stateTipNormal, alphaProperty, translationYProperty).setDuration(SWITCH_DURATION);

        translationYProperty = PropertyValuesHolder.ofFloat(
                TRANSLATION_Y, stateTipRapid.getTranslationY(), isRapidCharge ? CHARGE_TIP_TRANSLATE_SMALL : 0);
        alphaProperty = PropertyValuesHolder.ofFloat(
                ALPHA, stateTipRapid.getAlpha(), isRapidCharge ? 1 : 0);
        final ObjectAnimator tipRapidAnimator = ObjectAnimator.ofPropertyValuesHolder(
                stateTipRapid, alphaProperty, translationYProperty).setDuration(SWITCH_DURATION);

        scaleXProperty = PropertyValuesHolder.ofFloat(
                SCALE_X, rapidIcon.getScaleX(), isRapidCharge && !carMode ? 1 : 0);
        scaleYProperty = PropertyValuesHolder.ofFloat(
                SCALE_Y, rapidIcon.getScaleY(), isRapidCharge && !carMode ? 1 : 0);
        final ObjectAnimator rapidIconAnimator = ObjectAnimator.ofPropertyValuesHolder(
                carModeIcon, scaleXProperty, scaleYProperty).setDuration(SWITCH_DURATION);
        if (isRapidCharge && !carMode) {
            rapidIconAnimator.setInterpolator(new OvershootInterpolator(3));
        }

        scaleXProperty = PropertyValuesHolder.ofFloat(
                SCALE_X, carModeIcon.getScaleX(), carMode ? 1 : 0);
        scaleYProperty = PropertyValuesHolder.ofFloat(
                SCALE_Y, carModeIcon.getScaleY(), carMode ? 1 : 0);
        final ObjectAnimator carIconAnimator = ObjectAnimator.ofPropertyValuesHolder(
                carModeIcon, scaleXProperty, scaleYProperty).setDuration(SWITCH_DURATION);

        contentSwitchAnimator = new AnimatorSet();
        contentSwitchAnimator.playTogether(numberAnimator, tipAnimator, tipRapidAnimator);
        if (isRapidCharge) {
            contentSwitchAnimator.play(carIconAnimator).after(numberAnimator);
        } else {
            contentSwitchAnimator.play(carIconAnimator).with(numberAnimator);
        }
        contentSwitchAnimator.start();
    }

    public void setScreenOn(boolean screenOn) {
        this.isScreenOn = screenOn;
    }

    public void setProgress(float progress) {
        percentCountView.setProgress(progress);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        zoomLarge();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        handler.removeCallbacksAndMessages(null);
    }

    private void initAnimator() {
        zoomAnimator = ValueAnimator.ofInt(0, 1);
        zoomAnimator.setInterpolator(new LinearInterpolator());
        zoomAnimator.setDuration(ENTER_ANIMATION);
        zoomAnimator.addListener(this);
        zoomAnimator.addUpdateListener(this);
    }

    public void zoomLarge() {
        if (zoomAnimator == null) {
            initAnimator();
        }
        mStartingDismissWirelessAlphaAnim = false;
        hideSystemUI();
        setVisibility(VISIBLE);
        setAlpha(1.0f);
        if (zoomAnimator.isStarted()) {
            zoomAnimator.cancel();
        }
        zoomAnimator.start();
        circleView.startAnimation();
        circleRapidView.startAnimation();
    }

    @Override
    public void onAnimationUpdate(ValueAnimator animation) {
        setAlpha(animation.getAnimatedFraction());
        contentContainer.setScaleX(animation.getAnimatedFraction());
        contentContainer.setScaleY(animation.getAnimatedFraction());
        circleView.setScaleX(animation.getAnimatedFraction());
        circleView.setScaleY(animation.getAnimatedFraction());
        circleView.setAlpha(isRapidCharge ? 0 : animation.getAnimatedFraction());
        circleRapidView.setScaleX(animation.getAnimatedFraction());
        circleRapidView.setScaleY(animation.getAnimatedFraction());
        circleRapidView.setAlpha(isRapidCharge ? 1 - animation.getAnimatedFraction() : 0);
    }

    @Override
    public void onStart() {
        if (animationListener != null) {
            animationListener.onRapidAnimationStart(ChargeUtils.WIRELESS);
        }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startDismiss();
            }
        }, ANIMATION_DURATION - DISMISS_DURATION);
    }

    @Override
    public void onInterrupt() {

    }

    @Override
    public void onFinish() {
        if (animationListener != null) {
            animationListener.onRapidAnimationEnd(ChargeUtils.WIRELESS);
        }
    }

    @Override
    public void onAnimationStart(Animator animation) {
        Log.i(TAG, "onAnimationStart: ");
    }

    @Override
    public void onAnimationEnd(Animator animation) {
        Log.i(TAG, "onAnimationEnd: ");
    }

    @Override
    public void onAnimationCancel(Animator animation) {

    }

    @Override
    public void onAnimationRepeat(Animator animation) {

    }

    public void addToWindow() {
        if (isAttachedToWindow()) {
            return;
        }
        try {
            windowManager.addView(this, getWindowParam());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void startDismiss() {
        if (mStartingDismissWirelessAlphaAnim) {
            return;
        }
        PropertyValuesHolder alpha = PropertyValuesHolder.ofFloat("alpha",getAlpha(), 0);
        final ObjectAnimator alphaAnimator = ObjectAnimator.ofPropertyValuesHolder(
                this, alpha).setDuration(DISMISS_DURATION);
        alpha = PropertyValuesHolder.ofFloat("alpha",circleView.getAlpha(), 0);
        PropertyValuesHolder scaleX = PropertyValuesHolder.ofFloat("scaleX",circleView.getScaleX(), 0);
        PropertyValuesHolder scaleY = PropertyValuesHolder.ofFloat("scaleY",circleView.getScaleY(), 0);
        final ObjectAnimator circleViewAlphaAnimator
                = ObjectAnimator.ofPropertyValuesHolder(
                circleView, alpha, scaleX, scaleY).setDuration(DISMISS_DURATION);
        alpha = PropertyValuesHolder.ofFloat("alpha",circleRapidView.getAlpha(), 0);
        scaleX = PropertyValuesHolder.ofFloat("scaleX",circleRapidView.getScaleX(), 0);
        scaleY = PropertyValuesHolder.ofFloat("scaleY",circleRapidView.getScaleY(), 0);
        final ObjectAnimator circleRapidViewAlphaAnimator
                = ObjectAnimator.ofPropertyValuesHolder(
                        circleRapidView, alpha, scaleX, scaleY).setDuration(DISMISS_DURATION);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(alphaAnimator, circleViewAlphaAnimator, circleRapidViewAlphaAnimator);
        Animator.AnimatorListener animatorListener = new Animator.AnimatorListener() {

            @Override
            public void onAnimationStart(Animator animation) {
                Log.i(TAG, "onAnimationStart: ");
            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                mStartingDismissWirelessAlphaAnim = false;
                handler.post(mDismissRunnable);
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }
        };
        animatorSet.addListener(animatorListener);
        mStartingDismissWirelessAlphaAnim = true;
        animatorSet.start();
    }

    private final Runnable mDismissRunnable = new Runnable() {
        @Override
        public void run() {
            if (animationListener != null) {
                animationListener.onRapidAnimationDismiss(ChargeUtils.WIRELESS);
            }
            if (isScreenOn) {
                windowManager.removeView(WirelessRapidChargeView.this);
            } else {
                setVisibility(INVISIBLE);
            }
        }
    };

    public static WindowManager.LayoutParams getWindowParam() {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION,
                WindowManager.LayoutParams.FLAG_FULLSCREEN |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                        WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR |
                        WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED |
                        WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS |
                        WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM,
                PixelFormat.TRANSLUCENT);
        lp.windowAnimations = 0;
        return lp;
    }

    private IRapidAnimationListener animationListener;
    public void setRapidAnimationListener(IRapidAnimationListener listener) {
        animationListener = listener;
    }

    private void hideSystemUI() {
        int uiFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        uiFlags |= 0x00001000;
        setSystemUiVisibility(uiFlags);
    }
}
