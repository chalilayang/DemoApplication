package com.example.mi.view;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.mi.demoapplication.R;

public class RapidChargeView extends FrameLayout
        implements ValueAnimator.AnimatorUpdateListener,
        Animator.AnimatorListener, SurfaceFrameAnimation.FrameAnimationListener {

    private static final String TAG = "ChargingQuickView";
    private static final int FRAME_COUNT = 81;
    private static final int FRAME_INTERVAL = 40;
    public static final int ANIMATION_DURATION = FRAME_COUNT * FRAME_INTERVAL;
    private static final int DISMISS_DURATION = 300;
    private RelativeLayout contentContainer;
    private PercentCountView percentCountView;
    private TextView stateTip;

    private FrameAnimationView circleView;
    private FrameAnimationView dotView;
    private ValueAnimator zoomAnimator;

    private WindowManager windowManager;
    private Handler handler = new Handler();

    private boolean isScreenOn;
    private boolean isRapidCharge = false;

    private boolean mStartingDismissWirelessAlphaAnim;

    public RapidChargeView(Context context) {
        this(context, null);
    }

    public RapidChargeView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public RapidChargeView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }

    private void init(Context context) {
        isRapidCharge = false;
        setBackgroundColor(Color.BLACK);
        hideSystemUI();
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);

        LayoutParams flp = new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        flp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM;

        dotView = new FrameAnimationView(context, FRAME_COUNT, FRAME_INTERVAL, "rapid_charge_dot_");
        addView(dotView, flp);

        contentContainer = new RelativeLayout(context);
        View centerAnchorView = new TextView(context);
        RelativeLayout.LayoutParams rlp = new RelativeLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, (int) (6f * getResources().getDisplayMetrics().density));
        rlp.addRule(RelativeLayout.CENTER_IN_PARENT);
        centerAnchorView.setId(View.generateViewId());
        contentContainer.addView(centerAnchorView, rlp);

        rlp = new RelativeLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        rlp.addRule(RelativeLayout.CENTER_HORIZONTAL);
        rlp.addRule(RelativeLayout.ABOVE, centerAnchorView.getId());
        percentCountView = new PercentCountView(context);
        contentContainer.addView(percentCountView, rlp);

        stateTip = new TextView(context);
        stateTip.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15.54f);
        stateTip.setIncludeFontPadding(false);
        stateTip.setTextColor(Color.parseColor("#8CFFFFFF"));
        stateTip.setGravity(Gravity.CENTER);
        stateTip.setText(getResources().getString(R.string.wireless_normal_charge_mode_tip));
        rlp = new RelativeLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        rlp.addRule(RelativeLayout.CENTER_HORIZONTAL);
        rlp.addRule(RelativeLayout.BELOW, centerAnchorView.getId());
        contentContainer.addView(stateTip, rlp);

        flp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        addView(contentContainer, flp);


        flp = new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        flp.gravity = Gravity.CENTER;
        circleView = new FrameAnimationView(context, FRAME_COUNT, FRAME_INTERVAL, "rapid_charge_circle_");
        circleView.setAnimationCallback(this);
        addView(circleView, flp);
    }

    public void setIsRapidCharge(boolean rapid) {
        if (rapid != isRapidCharge) {
            startSwitchAnimation();
            isRapidCharge = rapid;
        }
    }

    private void startSwitchAnimation() {

    }

    public void setScreenOn(boolean screenOn) {
        this.isScreenOn = screenOn;
    }

    public void setProgress(float progress) {
        percentCountView.setProgress(progress);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        zoomLarge();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        handler.removeCallbacksAndMessages(null);
    }

    public void zoomLarge() {
        if (zoomAnimator == null) {
            initAnimator();
        }
        mStartingDismissWirelessAlphaAnim = false;
        hideSystemUI();
        setVisibility(VISIBLE);
        setAlpha(1.0f);
        if (!zoomAnimator.isStarted()) {
            zoomAnimator.cancel();
        }
        zoomAnimator.start();
        circleView.startAnimation();
        dotView.startAnimation();
    }

    private void initAnimator() {
        zoomAnimator = ValueAnimator.ofInt(0, 1);
        zoomAnimator.setInterpolator(new RapidChargeContentInterpolator());
        zoomAnimator.setDuration(ANIMATION_DURATION);
        zoomAnimator.addListener(this);
        zoomAnimator.addUpdateListener(this);
    }

    @Override
    public void onAnimationUpdate(ValueAnimator animation) {
        contentContainer.setScaleX(animation.getAnimatedFraction());
        contentContainer.setScaleY(animation.getAnimatedFraction());
        contentContainer.setAlpha(animation.getAnimatedFraction());
    }

    @Override
    public void onStart() {
        if (animationListener != null) {
            animationListener.onRapidAnimationStart(ChargeUtils.NORMAL);
        }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startDismiss();
            }
        }, ANIMATION_DURATION - DISMISS_DURATION + 200);
    }

    @Override
    public void onInterrupt() {

    }

    @Override
    public void onFinish() {
        if (animationListener != null) {
            animationListener.onRapidAnimationEnd(ChargeUtils.NORMAL);
        }
    }

    @Override
    public void onAnimationStart(Animator animation) {
    }

    @Override
    public void onAnimationEnd(Animator animation) {
    }

    @Override
    public void onAnimationCancel(Animator animation) {

    }

    @Override
    public void onAnimationRepeat(Animator animation) {

    }

    public void addToWindow() {
        if (isAttachedToWindow()) {
            return;
        }
        try {
            windowManager.addView(this, getWindowParam());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void startDismiss() {
        if (mStartingDismissWirelessAlphaAnim) {
            return;
        }
        final ObjectAnimator alphaAnimator = ObjectAnimator.ofFloat(
                this, "alpha", 1, 0).setDuration(DISMISS_DURATION);
        Animator.AnimatorListener animatorListener = new Animator.AnimatorListener() {

            @Override
            public void onAnimationStart(Animator animation) {
                Log.i(TAG, "onAnimationStart: ");
            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                mStartingDismissWirelessAlphaAnim = false;
                handler.post(mDismissRunnable);
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }
        };
        alphaAnimator.addListener(animatorListener);
        mStartingDismissWirelessAlphaAnim = true;
        alphaAnimator.start();
    }

    private final Runnable mDismissRunnable = new Runnable() {
        @Override
        public void run() {
            if (animationListener != null) {
                animationListener.onRapidAnimationDismiss(ChargeUtils.NORMAL);
            }
            if (isScreenOn) {
                windowManager.removeView(RapidChargeView.this);
            } else {
                setVisibility(INVISIBLE);
            }
            Integer.parseInt("dd");
        }
    };

    public static WindowManager.LayoutParams getWindowParam() {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION,
                WindowManager.LayoutParams.FLAG_FULLSCREEN |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                        WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR |
                        WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED |
                        WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS |
                        WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM,
                PixelFormat.TRANSLUCENT);
        lp.windowAnimations = 0;
        return lp;
    }

    private IRapidAnimationListener animationListener;
    public void setRapidAnimationListener(IRapidAnimationListener listener) {
        animationListener = listener;
    }

    private void hideSystemUI() {
        int uiFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        uiFlags |= 0x00001000;
        setSystemUiVisibility(uiFlags);
    }
}
